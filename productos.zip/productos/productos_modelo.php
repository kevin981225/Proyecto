<?php
	require_once('../modeloAbstractoDB.php');
	class Productos extends ModeloAbstractoDB {
		private $produ_codi;
		private $produ_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getprodu_codi(){
			return $this->produ_codi;
		}

		public function getprodu_nomb(){
			return $this->produ_nomb;
		}
		
          

		public function consultar($produ_codi='') {
			if($produ_codi != ''):
				$this->query = "
				SELECT produ_codi, produ_nomb
				FROM tb_productos
				WHERE produ_codi = '$produ_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT produ_codi, produ_nomb
			FROM tb_productos as p ORDER BY p.produ_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaProductos() {
			$this->query = "
			SELECT produ_codi, produ_nomb
			FROM tb_productos as p order by produ_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('produ_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_productos
				(produ_codi, produ_nomb)
				VALUES
				('$produ_codi', '$produ_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_productos
			SET produ_nomb='$produ_nomb'
			WHERE produ_codi = '$produ_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($produ_codi='') {
			$this->query = "
			DELETE FROM tb_productos
			WHERE produ_codi = '$produ_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
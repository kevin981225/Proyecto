<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.jpg' , 10 ,8, 15 , 20,'jpg');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Clientes"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE CLIENTES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(40, 8, 'Nombre', 0);
$pdf->Cell(40, 8, 'Apellido', 0);
$pdf->Cell(20, 8, 'Telefono', 0);
$pdf->Cell(50, 8, 'Email', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT clien_codi, clien_nomb, clien_ape, clien_tel, clien_email
				FROM tb_clientes
				");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['clien_codi'], 0);
	$pdf->Cell(40, 8,$productos2['clien_nomb'], 0);
	$pdf->Cell(40, 8, $productos2['clien_ape'] , 0);
	$pdf->Cell(20, 8,$productos2['clien_tel'], 0);
	$pdf->Cell(50, 8, $productos2['clien_email'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>
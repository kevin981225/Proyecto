<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.jpg' , 10 ,8, 15 , 20,'jpg');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Atenciones"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE ATENCIONES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(30, 8, 'Medico', 0);
$pdf->Cell(30, 8, 'Paciente', 0);
$pdf->Cell(30, 8, 'Fecha', 0);
$pdf->Cell(30, 8, 'Hora', 0);
$pdf->Cell(20, 8, 'Diagnostico', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT ME.aten_codi,E.medi_nomb, M.paciente_nomb,ME.Fecha, ME.Hora, ME.diag_desc
				FROM tb_atenciones AS ME 
					INNER JOIN tb_medicos AS E 
					ON ME.medi_codi = E.medi_codi 
					INNER JOIN tb_pacientes AS M 
					ON M.paciente_codi = ME.paciente_codi");
$item = 0;
while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['aten_codi'], 0);
	$pdf->Cell(30, 8,$productos2['medi_nomb'], 0);
	$pdf->Cell(30, 8, $productos2['paciente_nomb'], 0);
	$pdf->Cell(30, 8, $productos2['Fecha'], 0);
	$pdf->Cell(30, 8,$productos2['Hora'], 0);
	$pdf->Cell(20, 8, $productos2['diag_desc'], 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>
<?php
	require_once('../modeloAbstractoDB.php');
	class Gerentes extends ModeloAbstractoDB {
		private $geren_codi;
		private $geren_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getgeren_codi(){
			return $this->geren_codi;
		}

		public function getgeren_nomb(){
			return $this->geren_nomb;
		}
		
          

		public function consultar($geren_codi='') {
			if($geren_codi != ''):
				$this->query = "
				SELECT geren_codi, geren_nomb
				FROM tb_gerentes
				WHERE geren_codi = '$geren_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT geren_codi, geren_nomb
			FROM tb_gerentes as p ORDER BY p.geren_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listaPaises() {
			$this->query = "
			SELECT geren_codi, geren_nomb
			FROM tb_gerentes as p order by geren_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('geren_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_gerentes
				(geren_codi, geren_nomb)
				VALUES
				('$geren_codi', '$geren_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_gerentes
			SET geren_nomb='$geren_nomb'
			WHERE geren_codi = '$geren_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($geren_codi='') {
			$this->query = "
			DELETE FROM tb_gerentes
			WHERE geren_codi = '$geren_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
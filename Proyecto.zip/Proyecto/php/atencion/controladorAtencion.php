<?php
 
require_once 'atencion_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $atencion = new atencion();
        $resultado = $atencion->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $atencion = new atencion();
		$resultado = $atencion->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$atencion = new atencion();
		$resultado = $atencion->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $atencion = new atencion();
        $atencion->consultar($datos['codigo']);

        if($atencion->getAten_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $atencion->getaten_codi(),
                'medico' => $atencion->getmedi_codi(),
                'paciente' => $atencion->getPaciente_codi(),
                'Fecha' => $atencion->getFecha(),
                'Hora' => $atencion->getHora(),
                'diagnostico' => $atencion->getdiag_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $atencion = new atencion();
        $listado = $atencion->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>

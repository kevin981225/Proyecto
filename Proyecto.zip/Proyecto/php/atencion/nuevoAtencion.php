<!-- quick email widget -->

<script src="js/funcionesAtencion.js"></script>
<div id="seccion-atencion">
	<div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestión de Atencion</i>
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>


        <div class="panel-group"><div class="panel panel-primary">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fatencion">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="aten_codi">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="aten_codi" name="aten_codi" placeholder="Ingrese Codigo"
                            value = "" readonly="true"  data-validation="length alphanumeric" data-validation-length="3-12">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="medi_codi">Medico : </label>
                        <div class="col-sm-10">
                            <select class="form-control" id="medi_codi" name="medi_codi">
                         
							</select>	
                        </div>
                    </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="paciente_codi">Nombre Paciente:</label>
                            <div class="col-sm-10">
                            <select class="form-control" id="paciente_codi" name="paciente_codi">

                            </select>
                            </div>
                        </div>

                    <div class="form-group">
                            <label class="control-label col-sm-2" for="Fecha">Fecha : </label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" id="Fecha" name="Fecha" placeholder="Ingrese la Fecha de la cita" value="">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-2" for="Hora">Hora : </label>
                            <div class="col-sm-10">
                                <input type="time" class="form-control" id="Hora" name="Hora" placeholder="Ingrese la Hora de la cita" value="">
                            </div>
                        </div>

                     <div class="form-group">
                        <label class="control-label col-sm-2" for="diag_desc">Descripcion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="diag_desc" name="diag_desc" placeholder="Ingrese Descripcion paciente"
                            value = "">
                        </div>
                    </div>
					
				

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="grabar" class="btn btn-primary" data-toggle="tooltip" title="Grabar Atencion">Grabar Atencion</button>
                            <button type="button" id="cerrar" class="btn btn-success btncerrar2" data-toggle="tooltip" title="Cancelar">Historial</button>
                        </div>
                    </div>

					<input type="hidden" id="nuevo" value="nuevo" name="accion"/>
			</fieldset>

		</form>
	</div>
</div>


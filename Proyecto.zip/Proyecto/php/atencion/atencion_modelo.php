<?php
    require_once("../modeloAbstractoDB.php");
    class atencion extends ModeloAbstractoDB {
		private $aten_codi;
		private $medi_codi;
		private $paciente_codi;
		private $Fecha;
		private $Hora;
		private $diag_desc;
		
		function __construct() {
			//$this->db_name = '';
		}

		public function getaten_codi(){
			return $this->aten_codi;
		}

		public function getmedi_codi(){
			return $this->medi_codi;
		}
		
		public function getPaciente_codi(){
			return $this->paciente_codi;
		}
		public function getFecha(){
			return $this->Fecha;
		}
		public function getHora(){
			return $this->Hora;
		}
		public function getdiag_desc(){
			return $this->diag_desc;
		}


		public function consultar($aten_codi='') {
			if($aten_codi !=''):
				$this->query = "
				SELECT ME.aten_codi, E.medi_codi, M.paciente_codi, ME.Fecha, ME.Hora, ME.diag_desc
					FROM tb_atenciones AS ME 
					INNER JOIN tb_medicos AS E 
					ON ME.medi_codi = E.medi_codi 
					INNER JOIN tb_pacientes AS M 
					ON M.paciente_codi = ME.paciente_codi
					where ME.aten_codi = '$aten_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ME.aten_codi,E.medi_nomb, M.paciente_nomb,ME.Fecha, ME.Hora, ME.diag_desc
				FROM tb_atenciones AS ME 
					INNER JOIN tb_medicos AS E 
					ON ME.medi_codi = E.medi_codi 
					INNER JOIN tb_pacientes AS M 
					ON M.paciente_codi = ME.paciente_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('aten_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$medi_codi= utf8_decode($medi_codi);
			$paciente_codi= utf8_decode($paciente_codi);
			$Fecha= utf8_decode($Fecha);
			$Hora= utf8_decode($Hora);
			$diag_desc= utf8_decode($diag_desc);
				$this->query = "
					INSERT INTO tb_atenciones
					(aten_codi, medi_codi, paciente_codi, Fecha, Hora, diag_desc)
					VALUES
					(NULL, '$medi_codi', '$paciente_codi', '$Fecha','$Hora','$diag_desc')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
		
			$this->query = "
			UPDATE tb_atenciones
			SET medi_codi='$medi_codi',
			paciente_codi='$paciente_codi',
			Fecha='$fecha',
			Hora='$hora',
			diag_desc='$diag_desc' 
			WHERE aten_codi = '$aten_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($aten_codi='') {
			$this->query = "
			DELETE FROM tb_atenciones
			WHERE aten_codi = '$aten_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
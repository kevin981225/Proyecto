<?php
	require_once('../modeloAbstractoDB.php');
	class GrupoFamiliar extends ModeloAbstractoDB {
		private $grupofami_codi;
		private $grupofami_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getGrupofami_codi(){
			return $this->grupofami_codi;
		}

		public function getGrupofami_nomb(){
			return $this->grupofami_nomb;
		}

		public function consultar($paciente_codi='') {
			if($paciente_codi != ''):
				$this->query = "
				SELECT E.grupofami_codi, E.grupofami_nomb 
					FROM tb_paci_grupo AS ME 
					INNER JOIN tb_grupofamiliar AS E 
					ON ME.grupofami_codi = E.grupofami_codi 
					INNER JOIN tb_pacientes AS M 
					ON ME.paciente_codi = M.paciente_codi 
					where ME.paciente_codi = '$paciente_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}

		public function consultar1($grupofami_codi='') {
			if($grupofami_codi !=''):
				$this->query = "
				SELECT grupofami_codi, grupofami_nomb
				FROM tb_grupofamiliar
				WHERE grupofami_codi = '$grupofami_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT grupofami_codi, grupofami_nomb 
			FROM tb_grupofamiliar 
			ORDER BY grupofami_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function nuevo($datos=array()) {
			if(array_key_exists('grupofami_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
					INSERT INTO tb_grupofamiliar
					(grupofami_codi, grupofami_nomb)
					VALUES
					(NULL, '$grupofami_nomb')
					";
				$this->ejecutar_query_simple();
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
				
			endforeach;
			$this->query = "
			UPDATE tb_grupofamiliar
			SET grupofami_nomb='$grupofami_nomb'
			WHERE grupofami_codi = '$grupofami_codi'
			";
			$this->ejecutar_query_simple();
		}
		
		public function borrar($grupofami_codi='') {
			$this->query = "
			DELETE FROM tb_grupofamiliar
			WHERE grupofami_codi = '$grupofami_codi'
			";
			$this->ejecutar_query_simple();
		}
		
		
		function __destruct() {
			//unset($this);
		}
	}
?>
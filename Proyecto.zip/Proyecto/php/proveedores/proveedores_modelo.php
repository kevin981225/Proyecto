<?php
	require_once('../modeloAbstractoDB.php');
	class proveedores extends ModeloAbstractoDB {
		private $prove_codi;
		private $prove_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getprove_codi(){
			return $this->prove_codi;
		}

		public function getprove_nomb(){
			return $this->prove_nomb;
		}
		
          

		public function consultar($prove_codi='') {
			if($prove_codi != ''):
				$this->query = "
				SELECT prove_codi, prove_nomb
				FROM tb_proveedores
				WHERE prove_codi = '$prove_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT prove_codi, prove_nomb
			FROM tb_proveedores as p ORDER BY p.prove_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaProveedores() {
			$this->query = "
			SELECT prove_codi, prove_nomb
			FROM tb_proveedores as p order by prove_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('prove_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_proveedores
				(prove_codi, prove_nomb)
				VALUES
				('$prove_codi', '$prove_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_proveedores
			SET prove_nomb='$prove_nomb'
			WHERE prove_codi = '$prove_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($prove_codi='') {
			$this->query = "
			DELETE FROM tb_proveedores
			WHERE prove_codi = '$prove_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
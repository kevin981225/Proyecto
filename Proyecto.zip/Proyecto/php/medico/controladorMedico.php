<?php
 
require_once 'medico_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $medico = new medico();
        $resultado = $medico->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $medico = new medico();
		$resultado = $medico->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$medico = new medico();
		$resultado = $medico->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $medico = new medico();
        $medico->consultar($datos['codigo']);

        if($medico->getMedi_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $medico->getMedi_codi(),
                'medicos' => $medico->getMedi_nomb(),
                'edad' => $medico->getMedi_edad(),
                'tel' => $medico->getMedi_tel(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $medico = new medico();
        $listado = $medico->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>

<?php
	require_once('../modeloAbstractoDB.php');
	class Empleados extends ModeloAbstractoDB {
		private $emple_codi;
		private $emple_nomb;
		private $sede_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getemple_codi(){
			return $this->emple_codi;
		}

		public function getemple_nomb(){
			return $this->emple_nomb;
		}
		
		public function getsede_codi(){
			return $this->sede_codi;
		}                

		public function consultar($emple_codi='') {
			if($emple_codi != ''):
				$this->query = "
				SELECT emple_codi, emple_nomb, sede_codi
				FROM tb_empleados
				WHERE emple_codi = '$emple_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT emple_codi, emple_nomb, p.sede_nomb
			FROM tb_empleados as m inner join tb_sedes as p
			ON (m.sede_codi = p.sede_codi) ORDER BY m.emple_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listadepartamento() {
			$this->query = "
			SELECT emple_codi, emple_nomb
			FROM tb_empleados as d order by emple_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('emple_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_empleados
				(emple_codi, emple_nomb, sede_codi)
				VALUES
				('$emple_codi', '$emple_nomb', '$sede_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_empleados
			SET emple_nomb='$emple_nomb',
			sede_codi='$sede_codi'
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($emple_codi='') {
			$this->query = "
			DELETE FROM tb_empleados
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
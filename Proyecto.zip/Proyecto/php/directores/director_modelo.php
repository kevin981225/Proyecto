<?php
	require_once('../modeloAbstractoDB.php');
	class Director extends ModeloAbstractoDB {
		private $dir_codi;
		private $dir_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getdir_codi(){
			return $this->dir_codi;
		}

		public function getdir_nomb(){
			return $this->dir_nomb;
		}
		
          

		public function consultar($dir_codi='') {
			if($dir_codi != ''):
				$this->query = "
				SELECT dir_codi, dir_nomb
				FROM tb_directores
				WHERE dir_codi = '$dir_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $diredad=>$valor):
					$this->$diredad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT dir_codi, dir_nomb
			FROM tb_directores as p ORDER BY p.dir_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaDirectores() {
			$this->query = "
			SELECT dir_codi, dir_nomb
			FROM tb_directores as p order by dir_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('dir_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_directores
				(dir_codi, dir_nomb)
				VALUES
				('$dir_codi', '$dir_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_directores
			SET dir_nomb='$dir_nomb'
			WHERE dir_codi = '$dir_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($dir_codi='') {
			$this->query = "
			DELETE FROM tb_directores
			WHERE dir_codi = '$dir_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
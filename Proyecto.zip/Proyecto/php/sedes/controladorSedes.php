<?php
 
require_once 'sedes_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $sede = new sedes();
		$resultado = $sede->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $sede = new sedes();
		$resultado = $sede->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$sede = new sedes();
		$resultado = $sede->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $sede = new sedes();
        $sede->consultar($datos['codigo']);

        if($sede->getsede_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $sede->getsede_codi(),
                'sedes' => $sede->getsede_nomb(),
                'ciudad' =>$sede->getciu_codi(),
                'gerente' =>$sede->getgeren_codi(),
                'director' =>$sede->getdir_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $sede = new sedes();
        $listado = $sede->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>

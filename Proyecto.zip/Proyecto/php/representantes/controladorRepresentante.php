<?php
 
require_once 'representante_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $representante = new Representantes();
        $resultado = $representante->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $representante = new Representantes();
		$resultado = $representante->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$representante = new Representantes();
		$resultado = $representante->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $representante = new Representantes();
        $representante->consultar($datos['codigo']);

        if($representante->getRepresentante_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $representante->getRepresentante_codi(),
                'representante' => $representante->getRepresentante_nomb(),
                'edad' => $representante->getRepresentante_edad(),
                'dir' => $representante->getRepresentante_dir(),
                'tel' => $representante->getRepresentante_tel(),
                'email' => $representante->getRepresentante_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $representante = new Representantes();
        $listado = $representante->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>

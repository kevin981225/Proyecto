<?php
	require_once('../modeloAbstractoDB.php');
	class Representantes extends ModeloAbstractoDB {
		
		private $representante_codi;
		private $representante_nomb;
		private $representante_edad;
		private $representante_dir;
		private $representante_tel;
		private $representante_email;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getRepresentante_codi(){
			return $this->representante_codi;
		}

		public function getRepresentante_nomb(){
			return $this->representante_nomb;
		}
		
		public function getRepresentante_edad(){
			return $this->representante_edad;
		}
		public function getRepresentante_dir(){
			return $this->representante_dir;
		}

		public function getRepresentante_tel(){
			return $this->representante_tel;
		}
		
		public function getRepresentante_email(){
			return $this->representante_email;
		}
		

		public function consultar($grupofami_codi='') {
			if($grupofami_codi != ''):
				$this->query = "
				SELECT E.representante_codi, E.representante_nomb, E.representante_edad, E.representante_dir, E.representante_tel, E.representante_email
					FROM tb_grupo_rep AS ME 
					INNER JOIN tb_representantes AS E 
					ON ME.representante_codi = E.representante_codi 
					INNER JOIN tb_grupofamiliar AS M 
					ON ME.grupofami_codi = M.grupofami_codi 
					where ME.grupofami_codi = '$grupofami_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT E.representante_codi, E.representante_nomb, E.representante_edad, E.representante_dir, E.representante_tel, E.representante_email
				FROM tb_grupo_rep AS ME 
				INNER JOIN tb_representantes AS E 
				ON ME.representante_codi = E.representante_codi 
				INNER JOIN tb_grupofamiliar AS M 
				ON M.grupofami_codi = ME.grupofami_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('representante_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_representantes
					(representante_codi, representante_nomb, representante_edad, representante_dir, representante_tel, representante_email)
					VALUES
					(NULL, '$representante_nomb', '$representante_edad', '$representante_dir', '$representante_tel', '$representante_email')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$representante_nomb= utf8_decode($representante_nomb);
			$representante_edad= utf8_decode($representante_edad);
			$representante_dir= utf8_decode($representante_dir);
			$representante_tel= utf8_decode($representante_tel);
			$representante_email= utf8_decode($representante_email);
			$this->query = "
			UPDATE tb_representantes
			SET representante_nomb='$representante_nomb',
			representante_edad='$representante_edad',
			representante_dir='$representante_dir',
			representante_tel='$representante_tel',
			representante_email='$representante_email'
			WHERE representante_codi = '$representante_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($representante_codi='') {
			$this->query = "
			DELETE FROM tb_representantes
			WHERE representante_codi = '$representante_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
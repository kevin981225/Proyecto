<?php
 
require_once 'familia_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $paciente = new Familia();
        $resultado = $paciente->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $paciente = new Familia();
		$resultado = $paciente->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$paciente = new Familia();
		$resultado = $paciente->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $paciente = new Familia();
        $paciente->consultar($datos['codigo']);

        if($paciente->getPaciente_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $paciente->getPaciente_codi(),
                'paciente' => $paciente->getPaciente_nomb(),
                'edad' => $paciente->getPaciente_edad(),
                'tel' => $paciente->getPaciente_tel(),
                'email' => $paciente->getPaciente_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Paciente = new Familia();
        $listado = $Paciente->lista();
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);    
        break;
}
?>

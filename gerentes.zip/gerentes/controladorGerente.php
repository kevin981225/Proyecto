<?php
 
require_once 'gerente_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Gerentes = new Gerentes();
        $resultado = $Gerentes->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Gerentes = new Gerentes();
        $resultado = $Gerentes->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $Gerentes = new Gerentes();
        $resultado = $Gerentes->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Gerentes = new Gerentes();
        $Gerentes->consultar($datos['codigo']);

        if($Gerentes->getgeren_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Gerentes->getgeren_codi(),
                'Gerentes' => $Gerentes->getgeren_nomb(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Gerentes = new Gerentes();
        $listado = $Gerentes->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>

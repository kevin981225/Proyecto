<?php
	require_once('../modeloAbstractoDB.php');
	class sedes extends ModeloAbstractoDB {
		private $sede_codi;
		private $sede_nomb;
		private $ciu_codi;
		private $geren_codi;
		private $dir_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getsede_codi(){
			return $this->sede_codi;
		}

		public function getsede_nomb(){
			return $this->sede_nomb;
		}
		
		public function getciu_codi(){
			return $this->ciu_codi;
		} 

		public function getgeren_codi(){
			return $this->geren_codi;
		}  

		public function getdir_codi(){
			return $this->dir_codi;
		}                    

		public function consultar($sede_codi='') {
			if($sede_codi != ''):
				$this->query = "
				SELECT sede_codi, sede_nomb, ciu_codi, geren_codi, dir_codi
				FROM tb_sedes
				WHERE sede_codi = '$sede_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $diredad=>$valor):
					$this->$diredad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT sede_codi, sede_nomb, c.ciu_nomb, a.geren_nomb, p.dir_nomb 
			FROM tb_sedes as f 
				inner join tb_ciudades as c 
				ON f.ciu_codi = c.ciu_codi
				inner join tb_gerentes as a
				ON f.geren_codi = a.geren_codi
				inner join tb_directores as p
				ON f.dir_codi = p.dir_codi
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listasedes() {
			$this->query = "
			SELECT sede_codi, sede_nomb
			FROM tb_sedes as f order by sede_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('sede_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_sedes
					(sede_codi, sede_nomb, ciu_codi, geren_codi, dir_codi)
					VALUES
					(NULL, '$sede_nomb', '$ciu_codi', '$geren_codi', '$dir_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_sedes
			SET sede_nomb='$sede_nomb',
			ciu_codi='$ciu_codi',
			geren_codi='$geren_codi',
			dir_codi='$dir_codi'
			WHERE sede_codi = '$sede_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($sede_codi='') {
			$this->query = "
			DELETE FROM tb_sedes
			WHERE sede_codi = '$sede_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.jpg' , 10 ,8, 15 , 20,'jpg');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Notificaciones"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE NOTIFICACIONES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(120, 8, 'Descripcion', 0);
$pdf->Cell(30, 8, 'Sede', 0);
$pdf->Cell(40, 8, 'Cliente', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT noti_codi, noti_desc, c.sede_nomb, a.clien_nomb
			FROM tb_notificaciones as f 
				inner join tb_sedes as c 
				ON f.sede_codi = c.sede_codi
				inner join tb_clientes as a
				ON f.clien_codi = a.clien_codi
				");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['noti_codi'], 0);
	$pdf->Cell(120, 8,$productos2['noti_desc'], 0);
	$pdf->Cell(30, 8, $productos2['sede_nomb'] , 0);
	$pdf->Cell(40, 8, $productos2['clien_nomb'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>
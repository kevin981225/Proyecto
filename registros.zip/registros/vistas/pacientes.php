<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.jpg' , 10 ,8, 15 , 20,'jpg');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Pacientes"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE PACIENTES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(30, 8, 'Paciente', 0);
$pdf->Cell(30, 8, 'Edad', 0);
$pdf->Cell(30, 8, 'Telefono', 0);
$pdf->Cell(30, 8, 'Email', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT paciente_codi, paciente_nomb, paciente_edad, paciente_tel, paciente_email 
			FROM tb_pacientes 
			ORDER BY paciente_nomb");
$item = 0;
while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['paciente_codi'], 0);
	$pdf->Cell(30, 8,$productos2['paciente_nomb'], 0);
	$pdf->Cell(30, 8, $productos2['paciente_edad'], 0);
	$pdf->Cell(30, 8, $productos2['paciente_tel'], 0);
	$pdf->Cell(30, 8,$productos2['paciente_email'], 0);

	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>
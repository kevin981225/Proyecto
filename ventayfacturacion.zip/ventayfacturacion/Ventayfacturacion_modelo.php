<?php
	require_once('../modeloAbstractoDB.php');
	class Ventayfacturacion extends ModeloAbstractoDB {
		private $venta_codi;
		private $clien_codi;
		private $produ_codi;
		private $produ_cant;
		private $fecha;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getventa_codi(){
			return $this->venta_codi;
		}

		public function getclien_codi(){
			return $this->clien_codi;
		}
		
		public function getprodu_codi(){
			return $this->produ_codi;
		} 

		public function getprodu_cant(){
			return $this->produ_cant;
		}  

		public function getfecha(){
			return $this->fecha;
		}                    

		public function consultar($venta_codi='') {
			if($venta_codi != ''):
				$this->query = "
				SELECT venta_codi, clien_codi, produ_codi, produ_cant, fecha
				FROM tb_ventas
				WHERE venta_codi = '$venta_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT venta_codi, c.clien_nomb, a.produ_nomb, produ_cant, fecha 
			FROM tb_ventas as f 
				inner join tb_clientes as c 
				ON f.clien_codi = c.clien_codi
				inner join tb_productos as a
				ON f.produ_codi = a.produ_codi
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
	//	public function listafarmacias() {
	//		$this->query = "
	//		SELECT farma_codi, farma_nomb
	//		FROM tb_farmacias as f order by farma_nomb
	//		";
	//		$this->obtener_resultados_query();
	//		return $this->rows;
	//	}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('venta_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_ventas
					(venta_codi, clien_codi, produ_codi, produ_cant, fecha)
					VALUES
					(NULL, '$clien_codi', '$produ_codi', '$produ_cant', '$fecha')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_ventas
			SET clien_codi='$clien_codi',
			produ_codi='$produ_codi',
			produ_cant='$produ_cant',
			fecha='$fecha'
			WHERE venta_codi = '$venta_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($venta_codi='') {
			$this->query = "
			DELETE FROM tb_ventas
			WHERE venta_codi = '$venta_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
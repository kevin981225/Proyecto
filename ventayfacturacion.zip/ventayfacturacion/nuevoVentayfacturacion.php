<!-- quick email widget -->
<div id="seccion-ventayfacturacion">
	<div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestión de ventayfacturacion</i>
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>


        <div class="panel-group"><div class="panel panel-danger">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fventaf">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="venta_codi">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="venta_codi" name="venta_codi" placeholder="Ingrese Codigo"
                            value = "" readonly="true"  data-validation="length alphanumeric" data-validation-length="3-12">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="clien_codi">Clientes:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="clien_codi" name="clien_codi">
                         
                            </select>   
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="produ_codi">Productos:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="produ_codi" name="produ_codi">
                         
                            </select>   
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="produ_cant">Cantidad:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="produ_cant" name="produ_cant" placeholder="Ingrese Cantidad Producto"
                            value = "">
                        </div>
                    </div>
					
					<div class="form-group">
                        <label class="control-label col-sm-2" for="fecha">Fecha:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="fecha" name="fecha" placeholder="Ingrese fecha Venta"
                            value = "">
                        </div>
                    </div>

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="grabar" class="btn btn-danger" data-toggle="tooltip" title="Grabar Venta y Facturacion">Grabar Venta y Facturacion</button>
                            <button type="button" id="cerrar" class="btn btn-success btncerrar2" data-toggle="tooltip" title="Cancelar">Cancelar</button>
                        </div>
                    </div>

					<input type="hidden" id="nuevo" value="nuevo" name="accion"/>
			</fieldset>

		</form>
	</div>
</div>
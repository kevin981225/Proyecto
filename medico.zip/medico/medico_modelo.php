<?php
    require_once("../modeloAbstractoDB.php");
    class medico extends ModeloAbstractoDB {
		private $medi_codi;
		private $medi_nomb;
		private $medi_edad;
		private $medi_tel;
		
		function __construct() {
			//$this->db_name = '';
		}

		public function getMedi_codi(){
			return $this->medi_codi;
		}

		public function getMedi_nomb(){
			return $this->medi_nomb;
		}
		
		public function getMedi_edad(){
			return $this->medi_edad;
		}
		public function getMedi_tel(){
			return $this->medi_tel;
		}


		public function consultar($medi_codi='') {
			if($medi_codi !=''):
				$this->query = "
				SELECT medi_codi, medi_nomb, medi_edad, medi_tel
				FROM tb_medicos
				WHERE medi_codi = '$medi_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT medi_codi, medi_nomb, medi_edad, medi_tel
			FROM tb_medicos ORDER BY medi_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('medi_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$medi_nomb= utf8_decode($medi_nomb);
				$this->query = "
					INSERT INTO tb_medicos
					(medi_codi, medi_nomb, medi_edad, medi_tel)
					VALUES
					(NULL, '$medi_nomb', '$medi_edad', '$medi_tel')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$medi_nomb= utf8_decode($medi_nomb);
			$medi_edad= utf8_decode($medi_edad);
			$medi_tel= utf8_decode($medi_tel);
			$this->query = "
			UPDATE tb_medicos
			SET medi_nomb='$medi_nomb',
			medi_edad='$medi_edad',
			medi_tel='$medi_tel'
			WHERE medi_codi = '$medi_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($medi_codi='') {
			$this->query = "
			DELETE FROM tb_medicos
			WHERE medi_codi = '$medi_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
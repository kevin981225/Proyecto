<?php
 
require_once 'grupofamiliar_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    
    case 'editar':
        $grupofamiliar = new Grupofamiliar();
        $resultado = $grupofamiliar->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $grupofamiliar = new Grupofamiliar();
        $resultado = $grupofamiliar->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $grupofamiliar = new Grupofamiliar();
        $resultado = $grupofamiliar->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $grupofamiliar = new Grupofamiliar();
        $grupofamiliar->consultar($datos['codigo']);

        if($grupofamiliar->getGrupofami_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $grupofamiliar->getGrupofami_codi(),
                'grupofamiliar' => $grupofamiliar->getGrupofami_nomb(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

        case 'consultar1':
        $grupofamiliar = new Grupofamiliar();
        $grupofamiliar->consultar1($datos['codigo']);

        if($grupofamiliar->getGrupofami_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo1' => $grupofamiliar->getGrupofami_codi(),
                'grupofamiliar1' => $grupofamiliar->getGrupofami_nomb(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $grupofamiliar = new Grupofamiliar();
        $listado = $grupofamiliar->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>

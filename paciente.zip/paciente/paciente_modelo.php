<?php
    require_once("../modeloAbstractoDB.php");
    class paciente extends ModeloAbstractoDB {
		private $paciente_codi;
		private $paciente_nomb;
		private $paciente_edad;
		private $paciente_tel;
		private $paciente_email;
		
		function __construct() {
			//$this->db_name = '';
		}

		public function getPaciente_codi(){
			return $this->paciente_codi;
		}

		public function getPaciente_nomb(){
			return $this->paciente_nomb;
		}
		
		public function getPaciente_edad(){
			return $this->paciente_edad;
		}
		public function getPaciente_tel(){
			return $this->paciente_tel;
		}
		public function getPaciente_email(){
			return $this->paciente_email;
		}

		public function consultar($paciente_codi='') {
			if($paciente_codi !=''):
				$this->query = "
				SELECT paciente_codi, paciente_nomb, paciente_edad, paciente_tel, paciente_email
				FROM tb_pacientes
				WHERE paciente_codi = '$paciente_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT paciente_codi, paciente_nomb, paciente_edad, paciente_tel, paciente_email 
			FROM tb_pacientes 
			ORDER BY paciente_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
			
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('paciente_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$paciente_nomb= utf8_decode($paciente_nomb);
				$this->query = "
					INSERT INTO tb_pacientes
					(paciente_codi, paciente_nomb, paciente_edad, paciente_tel, paciente_email)
					VALUES
					(NULL, '$paciente_nomb', '$paciente_edad', '$paciente_tel', '$paciente_email')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$paciente_nomb= utf8_decode($paciente_nomb);
			$paciente_edad= utf8_decode($paciente_edad);
			$paciente_tel= utf8_decode($paciente_tel);
			$paciente_email= utf8_decode($paciente_email);
			$this->query = "
			UPDATE tb_pacientes
			SET paciente_nomb='$paciente_nomb',
			paciente_edad='$paciente_edad',
			paciente_tel='$paciente_tel',
			paciente_email='$paciente_email'
			WHERE paciente_codi = '$paciente_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($paciente_codi='') {
			$this->query = "
			DELETE FROM tb_pacientes
			WHERE paciente_codi = '$paciente_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
<?php
	require_once('../modeloAbstractoDB.php');
	class Roles extends ModeloAbstractoDB {
		private $rol_codi;
		private $rol_nomb;
		private $rol_desc;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getrol_codi(){
			return $this->rol_codi;
		}

		public function getrol_nomb(){
			return $this->rol_nomb;
		}

		public function getrol_desc(){
			return $this->rol_desc;
		}
		
          

		public function consultar($rol_codi='') {
			if($rol_codi != ''):
				$this->query = "
				SELECT rol_codi, rol_nomb, rol_desc
				FROM tb_roles
				WHERE rol_codi = '$rol_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT rol_codi, rol_nomb, rol_desc
			FROM tb_roles as r ORDER BY r.rol_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaPaises() {
			$this->query = "
			SELECT rol_codi, rol_nomb, rol_desc
			FROM tb_roles as r order by rol_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('rol_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_roles
				(rol_codi, rol_nomb, rol_desc)
				VALUES
				('$rol_codi', '$rol_nomb', '$rol_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_roles
			SET rol_nomb='$rol_nomb',
			 rol_desc='$rol_desc'
			WHERE rol_codi = '$rol_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($rol_codi='') {
			$this->query = "
			DELETE FROM tb_roles
			WHERE rol_codi = '$rol_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
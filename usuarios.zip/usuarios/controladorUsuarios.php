<?php
 
require_once 'Usuarios_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $usuarios = new Usuarios();
		$resultado = $usuarios->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $usuarios = new Usuarios();
		$resultado = $usuarios->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$usuarios = new Usuarios();
		$resultado = $usuarios->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $usuarios = new Usuarios();
        $usuarios->consultar($datos['codigo']);

        if($usuarios->getusu_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $usuarios->getusu_codi(),
                'usuarios' => $usuarios->getusu_nomb(),
                'password' => $usuarios->getusu_pass(),
                'rol' =>$usuarios->getrol_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $usuarios = new Usuarios();
        $listado = $usuarios->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>

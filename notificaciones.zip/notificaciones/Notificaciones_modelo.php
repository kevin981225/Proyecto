<?php
	require_once('../modeloAbstractoDB.php');
	class Notificaciones extends ModeloAbstractoDB {
		private $noti_codi;
		private $noti_desc;
		private $sede_codi;
		private $clien_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getnoti_codi(){
			return $this->noti_codi;
		}

		public function getnoti_desc(){
			return $this->noti_desc;
		}
		
		public function getsede_codi(){
			return $this->sede_codi;
		} 

		public function getclien_codi(){
			return $this->clien_codi;
		}  

		public function consultar($noti_codi='') {
			if($noti_codi != ''):
				$this->query = "
				SELECT noti_codi, noti_desc, sede_codi, clien_codi
				FROM tb_notificaciones
				WHERE noti_codi = '$noti_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT noti_codi, noti_desc, c.sede_nomb, a.clien_nomb
			FROM tb_notificaciones as f 
				inner join tb_sedes as c 
				ON f.sede_codi = c.sede_codi
				inner join tb_clientes as a
				ON f.clien_codi = a.clien_codi
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
	//	public function listafarmacias() {
	//		$this->query = "
	//		SELECT sede_codi, sede_nomb
	//		FROM tb_sedes as f order by sede_nomb
	//		";
	//		$this->obtener_resultados_query();
	//		return $this->rows;
	//	}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('noti_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_notificaciones
					(noti_codi, noti_desc, sede_codi, clien_codi)
					VALUES
					(NULL, '$noti_desc', '$sede_codi', '$clien_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_notificaciones
			SET noti_desc='$noti_desc',
			sede_codi='$sede_codi',
			clien_codi='$clien_codi'
			WHERE noti_codi = '$noti_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($noti_codi='') {
			$this->query = "
			DELETE FROM tb_notificaciones
			WHERE noti_codi = '$noti_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>
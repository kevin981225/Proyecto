<?php
 
require_once 'cita_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $Citas = new Citas();
		$resultado = $Citas->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $Citas = new Citas();
		$resultado = $Citas->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$Citas = new Citas();
		$resultado = $Citas->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $Citas = new Citas();
        $Citas->consultar($datos['codigo']);

        if($Citas->getcita_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $Citas->getcita_codi(),
                'paciente' => $Citas->getpaciente_codi(),
                'fecha' =>$Citas->getfecha(),
                'hora' =>$Citas->gethora(),
                'razon' =>$Citas->getrazon(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $Citas = new Citas();
        $listado = $Citas->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>

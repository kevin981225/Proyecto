<?php
	require_once('../modeloAbstractoDB.php');
	class Citas extends ModeloAbstractoDB {
		private $cita_codi;
		private $paciente_codi;
		private $fecha;
		private $hora;
		private $razon;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getcita_codi(){
			return $this->cita_codi;
		}

		public function getfecha(){
			return $this->fecha;
		}
		
		public function getpaciente_codi(){
			return $this->paciente_codi;
		}  

		public function gethora(){
			return $this->hora;
		}
		
		public function getrazon(){
			return $this->razon;
		}               

		public function consultar($cita_codi='') {
			if($cita_codi != ''):
				$this->query = "
				SELECT cita_codi, paciente_codi, fecha, hora, razon 
				FROM tb_citas
				WHERE cita_codi = '$cita_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT cita_codi, p.paciente_nomb, fecha, hora, razon 
			FROM tb_citas as m inner join tb_pacientes as p
			ON (m.paciente_codi = p.paciente_codi) ORDER BY m.fecha
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		/*
		public function listadepartamento() {
			$this->query = "
			SELECT cita_codi, fecha
			FROM tb_citas as d order by fecha
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}*/
		
		public function nuevo($datos=array()) {
			if(array_key_exists('cita_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_citas
				(cita_codi, paciente_codi, fecha, hora, razon)
				VALUES
				('$cita_codi', '$paciente_codi', '$fecha', '$hora', '$razon' )
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_citas
			SET paciente_codi='$paciente_codi',
			fecha='$fecha',
			hora='$hora',
			razon='$razon'
			WHERE cita_codi = '$cita_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($cita_codi='') {
			$this->query = "
			DELETE FROM tb_citas
			WHERE cita_codi = '$cita_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>